import { TradeNation } from "../page-objects/tradenation.page";


describe("Verify TradeNation UI Validation", () => {
        it(
          "Verify click to the Login to google link",
          () => {
            let tradeNationPage = new TradeNation();
            cy.visit(Cypress.config("loginUrl"))
            cy.wait(4000);
            tradeNationPage.verifyLoginClick();
            cy.wait(4000);
            cy.url().should('contain','');
          });
});