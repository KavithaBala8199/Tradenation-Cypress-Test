import { TradeNation } from "../page-objects/tradenation.page";


describe("Verify TradeNation UI Validation", () => {
    it(
      "Verify navigation to the tradeNation home page",
      () => {
        cy.visit(Cypress.config("baseUrl"))
        cy.title().should('eq','Ready to Trade On Popular Markets with Us? — Trade Nation')
      });

      it(
        "Verify click to the Trade Nation logo",
        () => {
          let tradeNationPage = new TradeNation();
          cy.visit(Cypress.config("baseUrl"))
          cy.wait(4000);
          tradeNationPage.verifyLogoClick();
          cy.wait(4000);
          cy.title().should('eq','Trade Nation - a broker with a global reach')
        });
});