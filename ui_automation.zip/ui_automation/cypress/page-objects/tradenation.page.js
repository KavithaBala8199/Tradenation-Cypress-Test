export const tradeNation = {
    //Campaign Information
    logoTradeNation: "a[data-testid='logo']",
    googleLogin: "div[class='SocialButton__SocialButtonContainer-sc-7ce8lz-0 cNibhT socialBtn__container']",
}

export class TradeNation{
    verifyLogoClick() {
        cy.get(tradeNation.logoTradeNation).click({ force: true });
        return this;
}

verifyLoginClick() {
    cy.get(tradeNation.googleLogin).eq(0).click({ force: true });
    return this;
}
}